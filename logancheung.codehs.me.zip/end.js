var timer = setInterval(launch,2000);
var stead;
var fast;
var sull;
var counter = 0;
var counter2 = 0;
var counter3 = 0;
var record = setInterval(best,1000)
var rundown = 20;
var fire = setInterval(boom,1000);
var minutes = 0;
var minutes2 = 0;
var recNum = 0;
var timeout = setTimeout(timers,2000);
function best(){
    recNum++;
    if(recNum > 60){
        minutes++;
        recNum = 0;
    }
    if(recNum >= 10){
        $("#time2").text(minutes + ":" + recNum)
    }else{
        $("#time2").text(minutes + ":0" + recNum)
    }
}
function boom(){
    if(rundown >= 60){
        minutes2++;
        rundown = rundown - 60;
    }
    
    if(rundown >= 10){
        $("#time").text(minutes2 + ":" + rundown);
    }else{
        $("#time").text(minutes2 + ":0" + rundown);
    }
    if(rundown <= 10 && minutes2 == 0){
        $("#timer").animate({color:"red"},250,function(){
            $("#timer").animate({color:"white"},250,function(){
                $("#timer").animate({color:"red"},250,function(){
                    $("#timer").animate({color:"white"},250)
                })
            })
        })
    }
    if(rundown == 0 && minutes2 >= 1){
        minutes2--;
        rundown = rundown + 60;
    }
    if(rundown == 0 && minutes2 == 0){
        clearInterval(fire);
        clearInterval(timer);
        clearInterval(record);
        clearInterval(stead);
        clearInterval(fast);
        clearInterval(sull);
        $("#go").css("display","initial")
    }
    rundown--;
}
function launch(){
    var math = Math.random()*3;
    $("#barrel").animate({height:"40px"},750,function(){
        $("#barrel").animate({height:"70px"},750)
    })
    if(Math.floor(math) == 0){
        $("#game").append("<div class = test></div>");
        check2 = $(".test").length;
        pcheck2 = check2 - 1;
        move()
    }else if(Math.floor(math) == 1){
        $("#game").append("<div class = fast></div>");
        check1 = $(".fast").length;
        pcheck1 = check1 - 1;
        speed()
    }else if(Math.floor(math) == 2){
        $("#game").append("<div class = dismal></div>");
        check3 = $(".dismal").length;
        pcheck3 = check3 - 1;
        sullen()
    }
}
function move(){
    $(".test").each(function(){
        $(this).animate({right:Math.floor(Math.random()*95) + "%",left:Math.floor(Math.random()*90) + "%",top:Math.floor(Math.random()*92) + "%"},650,function(){
        $(this).on("click",function(){
            $(this).remove();
            $("#time").text(minutes2 + ":" + rundown);
            rundown = rundown + 2;
            DontBoondoggle();
        })
        });
    })
}
function speed(){
    $(".fast").each(function(){
        $(this).animate({right:Math.floor(Math.random()*95) + "%",left:Math.floor(Math.random()*90) + "%",top:Math.floor(Math.random()*92) + "%"},500,function(){
        $(this).on("click",function(){
            $(this).remove();
            $("#time").text(minutes2 + ":" + rundown);
            rundown = rundown + 3;
            DontBoondoggle();
        })
        })
    })
}
function sullen(){
    $(".dismal").each(function(){
        $(this).animate({right:Math.floor(Math.random()*95) + "%",left:Math.floor(Math.random()*90) + "%",top:Math.floor(Math.random()*92) + "%"},1500,function(){
        $(this).on("click",function(){
            $(this).remove();
            $("#time").text(minutes2 + ":" + rundown);
            rundown = rundown + 1;
            DontBoondoggle();
        })
        });
    })
}
function timers(){
    stead = setInterval(move,800);
    fast = setInterval(speed,600);
    sull = setInterval(sullen,1600);
}
$('#go').click(function(){
    location.reload()
})