var timer = setInterval(show,400);
var showP = 20;
var recNum = 0;
var minutes = 0;
var record;
var moveInt = 2.5;
var width = window.innerWidth;
var x = 0;
var counter = 0;
var shutdown = setInterval(adieu,5200)

var y = 0;
if(localStorage.times){
    var scores = JSON.parse(localStorage.times); 
}else{
    var scores = [];
}
$("#test").animate({left:"80%"},4000,function(){
    $("#w").css("animation","dash 1.5s");
    $("#e").css("animation","dash 1.5s");
    $("#l").css("animation","dash 1.5s");
    $("#c").css("animation","dash 1.5s");
    $("#impG").css("animation","obedience 1.5s")
    $("#m").css("animation","dash 1.5s");
    $("#e2").css("animation","dash 1.5s");
    $("body").css("animation","crash 1.5s");
    $("#test").animate({width:"45%",height:"100%",top:"0%", borderRadius:"80%", left:"50%",backgroundColor:"red"},5000,function(){
        $(".ball").css("display","initial")
        $("#will").animate({left:"10%",top:"0%"},1000)
        $("#bill").animate({left:"60%",top:"40%"},1000)
        $("#kill").animate({left:"70%",top:"90%"},1000)
        $("#mill").animate({left:"5%",top:"90%"},1000)
        $("#till").animate({left:"50%",top:"0%"},1000)
        $("#test").animate({width:"0%",height:"0%",left:"40%",top:"50%",backgroundColor:"#B22222"},900,function(){
            $("#test").css("display","none")
        })
        timer = setInterval(hustle,550); 
        record = setInterval(time,1000);
    })
    var move = setInterval(function(){
    x += 2;
    if(x >= 250){
        clearInterval(move);
    } 
    $(".greet").css('transform',`translateX(-${x}px)`);
    console.log(x);
}, 0.16666666666);
});
function adieu(){
    $("#w").css("display","none");
    $("#e").css("display","none");
    $("#l").css("display","none");
    $("#c").css("display","none");
    $("#imp").css("display","none");
    $("#m").css("display","none");
    $("#e2").css("display","none");
}
function show(){
    showP = showP + moveInt;
    if(showP == 22.5){
        $("#w").css("display","initial")
    }else if(showP == 25){
        $("#e").css("display","initial")
    }else if(showP == 27.5){
        $("#l").css("display","initial")
    }else if(showP == 30){
        $("#c").css("display","initial")
    }else if(showP == 32.5){
        $("#imp").css("display","initial")
    }else if(showP == 35){
        $("#m").css("display","initial")
    }else if(showP == 37.5){
        $("#e2").css("display","initial")
    }
}
function hustle(){
    var lnum = Math.random()*92;
    var lnum2 = Math.floor(lnum);
    var rnum = Math.random()*92;
    var rnum2 = Math.floor(rnum);
    $("#will").animate({left:lnum2 + "%",top:rnum2 + "%"},500)
    $("#bill").animate({left:Math.floor(Math.random()*92) + "%",top:Math.floor(Math.random()*92) + "%"},500)
    $("#till").animate({left:Math.floor(Math.random()*92) + "%",top:Math.floor(Math.random()*92) + "%"},500)
    $("#mill").animate({left:Math.floor(Math.random()*92) + "%",top:Math.floor(Math.random()*92) + "%"},500)
    $("#kill").animate({left:Math.floor(Math.random()*92) + "%",top:Math.floor(Math.random()*92) + "%"},500)
}
$("#will").on("click",function(){
    counter++;
    $("#will").css("display","none");
    if(counter == 5){
        clearInterval(record);
        $("#go").css("display","initial")
    var score = {
        levelFour:$("#time").text(),
    }
    scores.push(score);
    localStorage.times = JSON.stringify(scores);
    }
})
$("#bill").on("click",function(){
    counter++;
    $("#bill").css("display","none");
    if(counter == 5){
        clearInterval(record);
        $("#go").css("display","initial")
    var score = {
        levelFour:$("#time").text(),
    }
    scores.push(score);
    localStorage.times = JSON.stringify(scores);
    }
})
$("#mill").on("click",function(){
    counter++;
    $("#mill").css("display","none");
    if(counter == 5){
        clearInterval(record);
        $("#go").css("display","initial")
    var score = {
        levelFour:$("#time").text(),
    }
    scores.push(score);
    localStorage.times = JSON.stringify(scores);
    }
})
$("#till").on("click",function(){
    counter++;
    $("#till").css("display","none");
    if(counter == 5){
        clearInterval(record);
        $("#go").css("display","initial")
    var score = {
        levelFour:$("#time").text(),
    }
    scores.push(score);
    localStorage.times = JSON.stringify(scores);
    }
})
$("#kill").on("click",function(){
    counter++;
    $("#kill").css("display","none");
    if(counter == 5){
        clearInterval(record);
        $("#go").css("display","initial")
    var score = {
        levelFour:$("#time").text(),
    }
    scores.splice(3, 1);
    localStorage.setItem("times", JSON.stringify(scores));
    scores.push(score);
    localStorage.times = JSON.stringify(scores);
        
    }
})
function time(){
    recNum++;
    if(recNum % 60 == 0){
        minutes++;
        recNum = 0;
    }
    if(recNum >= 10){
        $("#time").text(minutes + ":" + recNum)
    }else{
        $("#time").text(minutes + ":0" + recNum)
    }
}
$("#go").click(function(){
    $('body').css("z-index","40");
    $("#timer").css("display","none");
    $("#go").css("display","none");
    $("#game").css("display","none")
    $("#label").animate({color:"#F8F8FF"},3000)
    $('body').animate({backgroundColor:"#F8F8FF"},3000,function(){
        location.replace('doom.html')
    })
})