select();
var timer = setInterval(select,4000)
function select(){
    $("#test").animate({left:Math.floor(Math.random()*88) + "%",top:Math.floor(Math.random()*40) + "%"},4000)
    $("#test2").animate({left:Math.floor(Math.random()*88) + "%",top:Math.floor(Math.random()*40) + "%"},4000)
}
$("#test2").click(function(){
    location.replace("level-one.html");
    localStorage.removeItem('times');
})
$("#test").click(function(){
    location.replace("end.html");
})