var timer = setInterval(heheheha,600)
var record = setInterval(time,1000)
var recNum = 0;
var minutes = 0;
if(localStorage.times){
    var scores = JSON.parse(localStorage.times); 
}else{
    var scores = [];
}
function heheheha(){
    var num = Math.random()*9;
    var num2 = Math.floor(num);
    if(num2 == 1){
        $("#test").animate({left:"0%",top:"0%"},400);
        $("#shad").animate({left:"0%",top:"0%"},450);
        $("#chad").animate({left:"0%",top:"0%"},500);
    }else if(num2 == 2){
        $("#test").animate({left:"0%",top:"90%"},400);
        $("#shad").animate({left:"0%",top:"90%"},450);
        $("#chad").animate({left:"0%",top:"90%"},500);
    }else if(num2 == 3){
        $("#test").animate({left:"90%",top:"0%"},400);
        $("#shad").animate({left:"90%",top:"0%"},450);
        $("#chad").animate({left:"90%",top:"0%"},500);
    }else if(num2 == 4){
        $("#test").animate({left:"90%",top:"90%"},400);
        $("#shad").animate({left:"90%",top:"90%"},450);
        $("#chad").animate({left:"90%",top:"90%"},500);
    }else if(num2 == 5){
        $("#test").animate({left:"50%",top:"90%"},400);
        $("#shad").animate({left:"50%",top:"90%"},450);
        $("#chad").animate({left:"50%",top:"90%"},500);
    }else if(num2 == 6){
        $("#test").animate({left:"50%",top:"0%"},400);
        $("#shad").animate({left:"50%",top:"0%"},450);
        $("#chad").animate({left:"50%",top:"0%"},500);
    }else if(num2 == 7){
        $("#test").animate({left:"0%",top:"50%"},400);
        $("#shad").animate({left:"0%",top:"50%"},450);
        $("#chad").animate({left:"0%",top:"50%"},500);
    }else if(num2 == 8){
        $("#test").animate({left:"90%",top:"50%"},400);
        $("#shad").animate({left:"90%",top:"50%"},450);
        $("#chad").animate({left:"90%",top:"50%"},500);
    }
}
$("#test").click(function(){
    clearInterval(timer);
    clearInterval(record);
    $("#go").css("display","initial");
    $("#test").css("background-color","lime");
    $("#test").animate({left:"283px",top:"210px"},250);
    $("#chad").animate({left:"283px",top:"210px"},300);
    $("#shad").animate({left:"283px",top:"210px"},350);
    var score = {
        levelOne:$("#time").text(),
    }
    scores.splice(0, 1);
    localStorage.setItem("times", JSON.stringify(scores));
    scores.push(score);
    localStorage.times = JSON.stringify(scores);
    
})
$("#go").click(function(){
    location.replace("level-two.html")
})
function time(){
    recNum++;
    if(recNum % 60 == 0){
        minutes++;
        recNum = 0;
    }
    if(recNum >= 10){
        $("#time").text(minutes + ":" + recNum)
    }else{
        $("#time").text(minutes + ":0" + recNum)
    }
}