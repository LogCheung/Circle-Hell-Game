// 2 seconds for gif animation of devil laugh, 1500 milliseconds when mouth opens
// everytime devil open mouth, a ball will be sent out.
// hidden timer, shown once completed
// once player wins, all level times will be shown
//https://codehs.com/uploads/e271f5e5fd9edca44e10339e385d02b5
var timer;
var erupt;
var check = $(".fire").length;
var record = setInterval(time,1000);
var recNum = 0;
var minutes = 0;
var buzzer = 0;
var counter = 0;
if(localStorage.times){
    var scores = JSON.parse(localStorage.times); 
}else{
    var scores = [];
}
$("#go").click(function(){
    location.replace("how.html");
})
function time(){
    recNum++;
    if(recNum % 60 == 0){
        minutes++;
        recNum = 0;
    }
    if(recNum >= 10){
        buzzer = minutes + ":" + recNum;
    }else{
        buzzer = minutes + ":0" + recNum;
    }
}
$("body").animate({backgroundColor:"#DC143C"},2500,function(){
    $("#face").animate({width:"20%",height:"20%",top:"100%"},1500,function(){
        $("#flame").css('display',"flex");
        $("#flame2").css("display","flex");
        $("#game").css("display","flex");
        timer = setInterval(glad,3000);
    })
});
function glad(){
    if(check == 0){
        $("#game").append("<div class = fire></div>");
    }else if(check % 2 == 0){
        $("#game").append("<div id = meteor></div>");
        $("#meteor").animate({left:"50%",top:"40%",width:"250px",height:"250px"},600,function(){
            $("#meteor").remove();
            $("#game").append("<div id = fuego class = fire></div>");
            $("#game").append("<div id = fuego class = fire></div>");
        })
    }
    $("#game").append("<div class = fire></div>");
    check = $(".fire").length;
    console.log(check);

    erupt = setInterval(molt,200);
}
function molt(){
    $(".fire").each(function(){
    $(this).animate({left:Math.floor(Math.random()*88) + "%",top:Math.floor(Math.random()*92) + "%"},600,function(){
        $(this).css("position","relative");

    })
    
})
    $(".fire").each(function(){
        $(this).click(function(){
            $(this).remove()
            console.log(check);
            check = $(".fire").length;
            if(check == 0){
                $("#go").css("display","initial");
                $("#face").remove()
                $("#knight").css("display","initial")
                clearInterval(timer);
                clearInterval(erupt);
                clearInterval(record);
                store();
        }
    })
})
}

function store(){
    if(counter == 0){
        counter++;
        var score = {
            doom:buzzer,
        }
        scores.splice(4, 1);
        localStorage.setItem("times", JSON.stringify(scores));
        scores.push(score);
        localStorage.times = JSON.stringify(scores);
    }
}