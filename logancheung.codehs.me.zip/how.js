if(localStorage.times){
    var times = JSON.parse(localStorage.times)
    $("#one").text(times[0].levelOne);
    $("#two").text(times[1].levelTwo);
    $("#three").text(times[2].levelThree);
    $("#four").text(times[3].levelFour);
    $("#doom").text(times[4].doom);
}