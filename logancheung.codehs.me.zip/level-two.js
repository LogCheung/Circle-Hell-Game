var w = window.innerWidth;
var h = window.innerHeight;
var winC = 0;
var counter = 1;
var timer = setInterval(heheheha,500)
var record = setInterval(time,1000)
var recNum = 0;
var minutes = 0;
if(localStorage.times){
    var scores = JSON.parse(localStorage.times); 
}else{
    var scores = [];
}
function heheheha(){
    var num = Math.random()*9;
    var num2 = Math.floor(num);
    if(num2 == 1){
        $("#test").animate({left:"0%",top:"0%"},400);
    }else if(num2 == 2){
        $("#test").animate({left:"0%",top:"90%"},400);
    }else if(num2 == 3){
        $("#test").animate({left:"95%",top:"0%"},400);
    }else if(num2 == 4){
        $("#test").animate({left:"95%",top:"90%"},400);
    }else if(num2 == 5){
        $("#test").animate({left:"50%",top:"90%"},400);
    }else if(num2 == 6){
        $("#test").animate({left:"50%",top:"0%"},400);
    }else if(num2 == 7){
        $("#test").animate({left:"0%",top:"50%"},400);
    }else if(num2 == 8){
        $("#test").animate({left:"95%",top:"50%"},400);
    }
}
$("#test").click(function(){
    counter++;
    if(counter == 2){
        $("#test").animate({backgroundColor:"blue"},400);
        clearInterval(timer);
        $("#test").animate({left:"50%",top:"50%"},150)
        timer = setInterval(run,450)
    }
    if(counter == 3){
        $("#test").animate({backgroundColor:"green"},400);
        $("#test").animate({left:"50%",top:"50%"},150)
        clearInterval(timer);
        timer = setInterval(sprint,450)
    }
    if(counter == 4){
        $("#test").animate({backgroundColor:"lime"},400);
        $("#test").animate({left:"50%",top:"50%"},150)
        clearInterval(timer);
        clearInterval(record);
        $("#go").css("display","initial");
        var score = {
            levelTwo:$("#time").text(),
        }
        scores.splice(1, 1);
        localStorage.setItem("times", JSON.stringify(scores));
        scores.push(score);
        localStorage.times = JSON.stringify(scores);
    }
})
function run(){
        var num = Math.random()*13;
        var num2 = Math.floor(num);
        if(num2 == 1){
            $("#test").animate({left:"14%",top:"34%"},400);
        }else if(num2 == 2){
            $("#test").animate({left:"24%",top:"53%"},400);
        }else if(num2 == 3){
            $("#test").animate({left:"74%",top:"32%"},400);
        }else if(num2 == 4){
            $("#test").animate({left:"29%",top:"29%"},400);
        }else if(num2 == 5){
            $("#test").animate({left:"86%",top:"78%"},400);
        }else if(num2 == 6){
            $("#test").animate({left:"42%",top:"65%"},400);
        }else if(num2 == 7){
            $("#test").animate({left:"0%",top:"50%"},400);
        }else if(num2 == 8){
            $("#test").animate({left:"95%",top:"50%"},400);
        }else if(num2 == 9){
            $("#test").animate({left:"65%",top:"95%"},400);
        }else if(num2 == 10){
            $("#test").animate({left:"95%",top:"35%"},400);
        }else if(num2 == 11){
            $("#test").animate({left:"87%",top:"25%"},400);
        }else if(num2 == 12){
            $("#test").animate({left:"43%",top:"9%"},400);
        }
}
function sprint(){
    var num = Math.random()*21;
    var num2 = Math.floor(num);
    if(num2 == 1){
        $("#test").animate({left:"14%",top:"34%"},400);
    }else if(num2 == 2){
        $("#test").animate({left:"24%",top:"53%"},400);
    }else if(num2 == 3){
        $("#test").animate({left:"74%",top:"32%"},400);
    }else if(num2 == 4){
        $("#test").animate({left:"29%",top:"29%"},400);
    }else if(num2 == 5){
        $("#test").animate({left:"86%",top:"78%"},400);
    }else if(num2 == 6){
        $("#test").animate({left:"42%",top:"65%"},400);
    }else if(num2 == 7){
        $("#test").animate({left:"0%",top:"50%"},400);
    }else if(num2 == 8){
        $("#test").animate({left:"95%",top:"50%"},400);
    }else if(num2 == 9){
        $("#test").animate({left:"65%",top:"95%"},400);
    }else if(num2 == 10){
        $("#test").animate({left:"95%",top:"35%"},400);
    }else if(num2 == 11){
        $("#test").animate({left:"87%",top:"25%"},400);
    }else if(num2 == 12){
        $("#test").animate({left:"43%",top:"9%"},400);
    }else if(num2 == 13){
        $("#test").animate({left:"0%",top:"0%"},400);
    }else if(num2 == 14){
        $("#test").animate({left:"0%",top:"90%"},400);
    }else if(num2 == 15){
        $("#test").animate({left:"95%",top:"0%"},400);
    }else if(num2 == 16){
        $("#test").animate({left:"95%",top:"90%"},400);
    }else if(num2 == 17){
        $("#test").animate({left:"50%",top:"90%"},400);
    }else if(num2 == 18){
        $("#test").animate({left:"50%",top:"0%"},400);
    }else if(num2 == 19){
        $("#test").animate({left:"0%",top:"50%"},400);
    }else if(num2 == 20){
        $("#test").animate({left:"95%",top:"50%"},400);
    }
        
}

function time(){
    recNum++;
    if(recNum % 60 == 0){
        minutes++;
        recNum = 0;
    }
    if(recNum >= 10){
        $("#time").text(minutes + ":" + recNum)
    }else{
        $("#time").text(minutes + ":0" + recNum)
    }
}
// Level Three code





var t = 20;
var l = 50;
var leftInt = 1;
var tu = 60;
var lu = 50;
var rundown = 25;
var whiteC = 0;
$("#go").click(function(){
    winC++;
    if(winC == 1){
        $(".two").remove()
        $("#game-three").css("display","flex")  
        $(".three").css("display","initial");
        $("#go").css("display","none")
        $("body").animate({backgroundColor:"#455d7a"},3000);
        timer = setInterval(show,20)
    }else if(winC == 2){
        location.replace("level-four.html")
    }
})
function show(){
    //lies below
    //left 20 is left end,65 is right end.
    //top 20 is good up, 80 is good down
    if(tu <= 60 && tu >= 40){
        lu = lu - leftInt;
        tu--;
        $("#test-two").animate({left: lu + "%",top: tu + "%"},20);
    }else if(tu <= 40 && tu >= 20){
        tu--;
        lu = lu + leftInt;
        $("#test-two").animate({left: lu + "%",top: tu + "%"},20);
    }else{
        $("#test-two").animate({top:"35%"},500,function(){
        $("#alert").css("display","initial")
        $("#alert").animate({fontSize:"300px"},"slow")
        $("#test-two").animate({height:"500px",width:"500px",borderRadius:"50%",left:w/2 - 250 ,top:"0%",backgroundColor:"#42b883"},500,function(){
        $("#alert").remove();
        $("#test-two").animate({height:"60px",width:"60px",borderRadius:"50%",left:"50%",top:"44%",backgroundColor:"white"},1000, function(){
            $("#test-two").animate({top:"80%",left:"76%"},200)
            timer = setInterval(ramble,500);
            record = setInterval(quicker,1000);
            $("#time-three").text("0:" + rundown);
            fix()
        })
        })
        })
        clearInterval(timer);
    }
    
    if(t >= 20 && t < 40){
        l = l + leftInt;
        t++;
        $("#test-up").animate({left: l + "%",top: t + "%"},20);
    }else if(t >= 40 && t <= 60){
        t++;
        l = l - leftInt;
        $("#test-up").animate({left: l + "%",top: t + "%"},20);
    }else{
       $("#test-up").animate({top:"35%"},500,function(){
           $("#test-up").css("display","none");
       }); 
    }
}
function ramble(){
    var lnum = Math.random()*96;
    var lnum2 = Math.floor(lnum);
    var rnum = Math.random()*96;
    var rnum2 = Math.floor(rnum);
    $("#test-two").animate({left:lnum2 + "%",top:rnum2 + "%"},400)
}
function quicker(){
    if(rundown >= 10){
        $("#time-three").text(minutes + ":" + rundown);
    }else{
        $("#time-three").text(minutes + ":0" + rundown);
    }
    if(rundown <= 10){
        $("#time-three").animate({color:"red"},250,function(){
            $("#time-three").animate({color:"white"},250,function(){
                $("#time-three").animate({color:"red"},250,function(){
                    $("#time-three").animate({color:"white"},250)
                })
            })
        })
    }
    if(rundown == 0){
        clearInterval(timer);
        clearInterval(record);
        $("#test-two").animate({left:"50%",top:"45%"},"slow",function(){
            $("#retry").css("display","initial")
        })
        $("#test-two").off('click');
    }
    rundown--;
}
function fix(){
    $("#test-two").on('click',function(){
    clearInterval(timer);
    clearInterval(record);
    $("#go").css("display","initial");
    $("#test-two").animate({left:"50%",top:"45%"},"slow")
    $("#test-two").animate({backgroundColor:"lime"},"slow")
    var rTime = 25 - rundown; 
    if(rTime >= 10){
        rTime = "0:" + rTime;
    }else{
        rTime = "0:0" + rTime;
    }
    var score = {
        levelThree:rTime,
    }
    scores.splice(2, 1);
    localStorage.setItem("times", JSON.stringify(scores));
    scores.push(score);
    localStorage.times = JSON.stringify(scores);
    $("#test-two").off('click');
})
}
$("#retry").on('click',function(){
    $("#test-two").css("top","60%");
    $("#test-two").css("left","50%");
    $("#test-two").css("background-color","yellow");
    $("#test-up").css("left","50%");
    $("#test-up").css("top","18%");
    $("#retry").css("display","none");
    $("#test-up").css("display","flex");
    tu = 60;
    t = 20;
    rundown = 25;
    timer = setInterval(show,20);
})